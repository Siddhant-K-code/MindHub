<?php
require_once("common.inc.php");

displayPageHeader("FAQ",true);
startWrapper();
if ( isset( $_POST["action"] ) and $_POST["action"] == "ask" ){
    processForm();
} else {
    displayForm(array(), array(), new Member(array()));
}

function displayForm( $errorMessages, $missingFields, $member ) {
    displayPageHeader( "FAQ", true );

    echo '<br><br>
<div class="container">
<div class="row">
<div class="col-md-offset-4 col-md-12 col-xs-12">
<form class="form-horizontal" action="Query.php" method="post" id="login_form" style="margin: 0 auto;">

<!-- Hidden Action Field -->
<input type="hidden" name="action" value="ask" />

<!-- Text input-->
<div class="form-group">
  <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input name="query_Id" placeholder="Question ID" class="form-control"  type="text">
    </div>
  </div>
</div>
<!-- Button -->
<div class="form-group">
  <div class="col-md-4">
    <button type="submit" class="btn btn-warning" > Login </button>
  </div>
</div>
';
echo '
</form>
</div>
</div>

</div>
 ';

}

function processForm() {
    $requiredFields = array( "query_Id" );
    $missingFields = array();
    $errorMessages = array();

    $question = new Query( array(
        "query_Id" => isset( $_POST["query_Id"] ) ? preg_replace( "/[^ \-\_a-zA-Z0-9]/", "", $_POST["query_Id"] ) : ""
    ) );

    foreach ( $requiredFields as $requiredField ) {
        if ( !$member->getValue( $requiredField ) ) {
            $missingFields[] = $requiredField;
        }
    }

    if($missingFields){
        $errorMessages[] = '<p class="error">*Enter all the necessary fields</p>';
    }

    if ( $errorMessages ) {
        displayForm( $errorMessages, $missingFields, $member );
    }
}


endWrapper();
displayPageFooter();
?>