<?php
require_once( "common.inc.php" );
session_start();
date_default_timezone_set("Asia/Kolkata");

if (!(isset($_SESSION['member']) && $_SESSION['member'] != '')) {
    header ("Location: login.php");
}

displayPageHeader('Query',true);
startWrapper();

$query_Id = $_GET['itemId'];
$query = Query::getQuery($query_Id);
$answers = Answer::getAllAnswers($query_Id);
$member = Member::getMember($query["askedBy"]);
$date = date("F jS, Y", strtotime($query["askedOn"]));

echo '
<a href="ask.php"><button class="btn btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to Question List</button></a><br><br>';

echo '<h4><span class="glyphicon glyphicon-align-left"></span> '.$query["question"].'</h4>';
echo '
<p style="color: gray;font-weight: 300;"><strong>'.$member->getFirstNameString().' '.$member->getLastNameString().'</strong> on '.$date.'</p>
<hr>
';

if ( isset( $_POST["action"] ) and $_POST["action"] == "answer" ){
    processAnswerForm();
} else {
    displayAnswerForm(array(), array(), new Answer(array()));
}

function displayAnswerForm( $errorMessages, $missingFields, $member ){

echo '
<div id="post-answer">
<form class="form-horizontal" action="answer.php?itemId='.$_GET["itemId"].'" method="post">

  <!-- Hidden Action Field -->
  <input type="hidden" name="action" value="answer" />
  
  <div class="form-group">
    <div class="col-sm-10">
      <input type="text" class="form-control" name="answer" id="answer" placeholder="Share your thoughts on this question." required>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-default">Answer</button>
    </div>
  </div>
</form>
</div>';


    if ( $errorMessages ) {
        foreach ($errorMessages as $errorMessage) {
            echo '      ' . $errorMessage;
        }
    }

}

function processAnswerForm() {

    $requiredFields = array("answer");
    $missingFields = array();
    $errorMessages = array();

    $member = $_SESSION['member'];
    $query_Id = $_GET["itemId"];

    $answer = new Answer( array(
        "answer" => isset( $_POST["answer"] ) ? ( $_POST["answer"] ) : "",
        "query_Id" => $query_Id,
        "userId" => $member->getValue("ID")
    ) );

    foreach ( $requiredFields as $requiredField ) {
        if ( !$answer->getValue( $requiredField ) ) {
            $missingFields[] = $requiredField;
        }
    }

    if( $missingFields ){
        $errorMessages[] = '<p class="error">Please select which side of the debate are you on! For the motion or against the motion.</a></p>';
    } elseif (($answered = $answer->submit())<=0 ){
        $errorMessages[] = '<p class="error">The comment was not posted! Please try again or <a href="contact.php">Contact Us</a> if you are continuously facing the issue.</a></p><br>';
    }

    if ( $errorMessages ) {
        displayAnswerForm( $errorMessages, $missingFields, $answer );
    } else {
        echo '<div class="well well-sm">Thank you for your valuable answer. <a href="answer.php?itemId='.$query_Id.'">Refresh page to view it</a>.</div>';
    }
}

echo '<div class="row">';
if($answers!=null) {
	echo '<h4><span class="glyphicon glyphicon-thumbs-up"></span> Previous Answers</h4>';
    foreach ($answers as $answer) {
        $member = Member::getMember($answer["answeredBy"]);
        $date = date("F jS, Y", strtotime($answer["answeredOn"]));
        echo '<li class="list-group-item">' . $answer["answer"] . ' <small>posted on '.$date.' by '.$member->getFirstNameString().' '.$member->getLastNameString().'</small></li>';
    }
}
echo '
</div>
';

endWrapper();
displayPageFooter();
?>