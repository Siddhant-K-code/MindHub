<?php

require_once( "common.inc.php" );
session_start();

$current_user = $_SESSION["member"];
$user_id = $current_user->getIdString();
$memberId = isset( $_REQUEST["memberId"] ) ? (int)$_REQUEST["memberId"] : 0;
startWrapper();
if ( !$member = Member::getMember( $memberId ) ) {
	displayPageHeader( "Error" );
	echo "<div>Member not found.</div>";
	displayPageFooter();
	exit;
}

if ( isset( $_POST["action"] ) and $_POST["action"] == "Save Changes" ) {
	saveMember();
}	elseif ( isset( $_POST["action"] ) and $_POST["action"] == "Delete Member" ){
	deleteMember();
}	else {
	displayForm( array(), array(), $member );
}

function displayForm( $errorMessages, $missingFields, $member ) {
	$logEntries = LogEntry::getLogEntries( $member->getValue( "ID" ) );
	displayPageHeader( "View Member: " . $member->getValueEncoded( "firstName" ) . " " . $member->getValueEncoded( "lastName" ) );
	if ( $errorMessages ) {
		foreach ( $errorMessages as $errorMessage ) {
			echo $errorMessage;
		}
	}
	
	$start = isset( $_REQUEST["start"] ) ? (int)$_REQUEST["start"] : 0;
	$order = isset( $_REQUEST["order"] ) ? preg_replace( "/[^ a-zA-Z]/", "", $_REQUEST["order"] ) : "username";
?>
<style type="text/css">


/* All form elements are within the definition list for this example */
dl {
	position: relative;
	width: 350px;
}
dt {
	clear: both;
	float:left;
	width: 130px;
	padding: 4px 0 2px 0;
	text-align: left;
}
dd {
	float: left;
	width: 210px;
	margin: 0 0 8px 0;
	padding-left: 6px;
}
</style>
	<form action="view_member.php" method="post" style="margin-bottom:50px;text-align:left;">
		<div style="width:30em;">
			<input type="hidden" name="memberId" id="memberId" value="<?php echo $member->getValueEncoded("ID") ?>" />
			<input type="hidden" name="start" id="start" value="<?php echo $start ?>" />
			<input type="hidden" name="order" id="order" value="<?php echo $order ?>" />
			<dl>
			<dt><label for="firstName">First Name </label></dt>
			<dd><?php echo $member->getValue("firstName") ?></dd>
			
			<dt><label for="lastName">Last Name </label></dt>
			<dd><?php echo $member->getValue("lastName") ?></dd>
			
			<dt><label for="dateOfBirth">Date Of Birth</label></dt>
			<dd><?php echo $member->getValue("dateOfBirth") ?></dd>
			
			<dt><label for="gender">Gender</label></dt>
			<dd><?php if ( $member->getValue("gender") == "m") {
				echo "Male";
			}	else {
				echo "Female";
			}?></dd>
			
			<?php if( $user_id == $member->getValue("ID") ) { ?>
			<dt><label for="username"<?php validateField( "username", $missingFields ) ?>>Username* </label></dt>
			<dd><input type="text" name="username" id="username" value="<?php echo $member->getValue( "username" )?>" style="height:30px;" /></dd>
			
			<dt><label for="password"<?php validateField( "password", $missingFields ) ?>>New Password </label></dt>
			<dd><input type="password" name="password" id="password" value="" style="height:30px;" /></dd>
			
			<dt><label for="emailAddress">Email Address</label></dt>
			<dd><?php echo $member->getValue("emailAddress") ?></dd>
			</dl>
			<div style="clear: both;">
				<input type="submit" class="btn btn-link-1" name="action" id="saveButton" value="Save Changes" style="padding:0 10;"/ >
				<input type="submit" class="btn btn-link-1" name="action" id="deleteButton" value="Delete Member" style="margin-right: 20px; padding:0 10;" / >
			</div>
			<?php } ?>
		</div>
	</form>
	
	<h2>Access Log</h2>
	
	<table cellspacing="0" style="width:45em; font size:20px;">
		<tr>
			<th style="padding: 10 10;">Web Page</th>
			<th style="padding: 10 10;">Number of Visits</th>
			<th style="padding: 10 10;">Last Visit</th>
		</tr>
<?php
$rowCount = 0;

foreach ( $logEntries as $logEntry ) {
	$rowCount++;
?>
		<tr <?php if ( $rowCount % 2 == 0 ) echo ' class="alt"' ?>>
			<td style="padding: 5 5;"><?php echo $logEntry->getValueEncoded( "pageUrl" ) ?></td>
			<td style="padding: 5 5;"><?php echo $logEntry->getValueEncoded( "numVisits" ) ?></td>
			<td style="padding: 5 5;"><?php echo $logEntry->getValueEncoded( "lastAccess" ) ?></td>
		</tr>
<?php } ?>
	</table>
	
	<div style="width:30em; margin-top:20px; text-align:center;">
		<a href="view_members.php?start=<?php echo $start ?>&amp;order=<?php echo $order ?>">Back</a>
	</div>
<?php
	displayPageFooter();
}

function saveMember() {
	$requiredFields = array( "username", "password" );
	$missingFields = array();
	$errorMessages = array();
	$member = new Member( array(
		"username" => isset( $_POST["username"] ) ? preg_replace( "/[^ \-\_a-zAZ0-9]/", "", $_POST["username"] ) : "",
		"password" => isset( $_POST["password"] ) ? preg_replace( "/[^ \-\_a-zAZ0-9]/", "", $_POST["password"] ) : "",
		"emailAddress" => $_SESSION["member"]->getValue( "emailAddress" ),
		"firstName" => $_SESSION["member"]->getValue( "firstName" ),
		"lastName" => $_SESSION["member"]->getValue( "lastName" ),
		"gender" => $_SESSION["member"]->getValue( "gender" )
	) );
	foreach ( $requiredFields as $requiredField ) {
		if ( !$member->getValue( $requiredField ) ) {
			$missingFields[] = $requiredField;
		}
	}
	if ( $missingFields ) {
		$errorMessages[] = ' < p class="error" > There were some missing fields in the form you submitted. Please complete the fields highlighted below and click Save Changes to resend the form. < /p > ';
	}
	if ( $existingMember = Member::getByUsername( $member->getValue( "username") ) and $existingMember->getValue( "memberId" ) != $member->getValue( "memberId" ) ) {
		$errorMessages[] = ' < p class="error" > A member with that username already exists in the database. Please choose another username. < /p > ';
	}
	if ( $existingMember = Member::getByEmailAddress( $member->getValue("emailAddress" ) ) and $existingMember->getValue( "id" ) != $member->getValue( "id" ) ) {
		$errorMessages[] = ' < p class="error" > A member with that email address already exists in the database. Please choose another email address. < /p > ';
	}
	if ( $errorMessages ) {
		displayForm( $errorMessages, $missingFields, $member );
	} else {
		$member->update();
		displaySuccess();
	}
}
function deleteMember() {
	$member = new Member( array(
		"id" => isset( $_POST["memberId"] ) ? (int) $_POST["memberId"] : "",
	) );
	LogEntry::deleteAllForMember( $member->getValue( "id" ) );
	$member->delete();
	displaySuccess();
}
function displaySuccess() {
	$start = isset( $_REQUEST["start"] ) ? (int)$_REQUEST["start"] : 0;
	$order = isset( $_REQUEST["order"] ) ? preg_replace( "/[^ a-zA-Z]/", "",
	$_REQUEST["order"] ) : "username";
	displayPageHeader( "Changes saved" );
?>
<p> Your changes have been saved. <a href="view_members.php?start= <?php
echo $start ?>&amp;order=<?php echo $order ?> " > Return to member list </a></p>
<?php
displayPageFooter();
}
?>
</center>