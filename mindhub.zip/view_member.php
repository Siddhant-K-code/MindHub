<?php
require_once( "common.inc.php" );
date_default_timezone_set("Asia/Kolkata");
session_start();
if (!(isset($_SESSION['member']) && $_SESSION['member'] != '')) {
    header ("Location: login.php");
}

$user =  $_SESSION["member"];

$memberId = isset( $_REQUEST["memberId"] ) ? (int)$_REQUEST["memberId"] : 0;

if ( !$member = Member::getMember( $memberId ) ) {
	header("Location:profile.php");
    exit();

    displayPageFooter();
}

displayPageHeader('Profile',true);
startWrapper();

echo '<div class="page-header"><h2>'.$member->getFirstNameString().' '.$member->getLastNameString().'</h2></div>';

$dob = date("F jS, Y", strtotime($member->getDOBString()));
if ( $member->getValue("gender") == "m") {
	$gen="Male";
}	else {
	$gen="Female";
}
echo '
<div class="list-group">
<h4> &nbsp; Public Information</h4>
<li class="list-group-item">Username : '.$member->getUsernameString().'</li>
<li class="list-group-item">Gender : '.$gen.'</li>
<li class="list-group-item">Date of Birth : '.$dob.'</li>
</div>
';
if ( $memberId == $user->getIdString() ) {
	echo '
	<h4> &nbsp; Private Information</h4>
	<li class="list-group-item">Email Address : '.$member->getEmailString().'</li>
	<li class="list-group-item">Institute : '.$member->getInstituteString().'</li>
	';
}
endWrapper();
displayPageFooter();
?>