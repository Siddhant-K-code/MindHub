<?php
require_once( "common.inc.php" );
session_start();
if (!(isset($_SESSION['member']) && $_SESSION['member'] != '')) {
    header ("Location: login.php");
}

displayPageHeader('Debate',true);
startWrapper();

$debates = Debate::getAllDebates();

echo '<div class="page-header"><h2>Debate <small>Read all the ongoing debates or start a new one.</small ></h2></div>';

if ( isset( $_POST["action"] ) and $_POST["action"] == "postDebate" ){
    processDebateForm();
} else {
    displayDebateForm(array(), array(), new Debate(array()));
}

function displayDebateForm( $errorMessages, $missingFields, $member ) {

    echo '

<div id="post-debate">
<form class="form-horizontal" action="debate.php" method="post">

  <!-- Hidden Action Field -->
  <input type="hidden" name="action" value="postDebate" />
  
  <div class="form-group">
    <div class="col-sm-10">
      <input type="text" class="form-control" name="debateTitle" id="debateTitle" placeholder="Title - (e.g. Technology is the only way to fix real world problems. Agree or Disagree?)" required>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-default">Start a Debate</button>
    </div>
  </div>
</form>
</div><br/>';


    if ( $errorMessages ) {
        foreach ($errorMessages as $errorMessage) {
            echo '      ' . $errorMessage;
        }
    }

}

function processDebateForm() {
    $requiredFields = array("debateTitle");
    $missingFields = array();
    $errorMessages = array();

    $member = $_SESSION['member'];

    $debate = new Debate( array(
        "debateTitle" => isset( $_POST["debateTitle"] ) ? ( $_POST["debateTitle"] ) : "",
        "userId" => $member->getValue("ID"),
    ) );

    foreach ( $requiredFields as $requiredField ) {
        if ( !$debate->getValue( $requiredField ) ) {
            $missingFields[] = $requiredField;
        }
    }

    if( $missingFields ){
        $errorMessages[] = '<p class="error">Enter a topic to start a debate.</a></p>';
    } elseif ( ($debatePosted = $debate->submit())<=0 ){
        $errorMessages[] = '<p class="error">The debate could not be created! Please try again or <a href="contact.php">Contact Us</a> if you are continuously facing the issue.</a></p><br>';
    }

    if ( $errorMessages ) {
        displayDebateForm( $errorMessages, $missingFields, $debate );
    } else {
        echo '<div class="well well-sm">Thank you for starting a new Debate. <a href="debateitem.php?itemId='.$debatePosted.'">Click here to know more about it</a>.</div>';
    }
}

echo '<h4><span class="glyphicon glyphicon-flash"></span> Trending Debates</h4>';
echo '<div class="list-group">';

if($debates!=null) {
    date_default_timezone_set("Asia/Kolkata");
    foreach ($debates as $debate) {
        $member = Member::getMember($debate["user_id"]);
        $date = date("F jS, Y", strtotime($debate["date_posted"]));
        echo '<a href="debateitem.php?itemId=' . $debate["debate_id"] . '" class="list-group-item">' . $debate["debate_title"] . ' <small>posted on '.$date.' by '.$member->getFirstNameString().' '.$member->getLastNameString().'</small></a>';
    }
}else{
    echo 'There are no debate topics in the system yet. Start the activity by creating a new debatable topic.';
}
echo '</div>';

endWrapper();
displayPageFooter();

