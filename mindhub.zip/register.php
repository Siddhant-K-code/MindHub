<?php
require_once( "common.inc.php" );
session_start();

if(isset($_SESSION['member'])){
    header("Location: home.php");
}
if ( isset( $_POST["action"] ) and $_POST["action"] == "register" ){
    processForm();
} else {
    displayForm(array(), array(), new Member(array()));
}

function displayForm( $errorMessages, $missingFields, $member ) {
    displayPageHeader( "Register", true );

    echo '<br>
<div class="container">
<h1 class="text-center" style="font-family: Righteous;color: dimgray;">MindHub.</h1>
<h4 class="text-center">Create a new MindHub account.</h4><br>
<div class="row">
<div class="col-md-offset-4 col-md-12 col-xs-12">
<form class="form-horizontal" action="register.php" method="post" id="register_form" style="margin: 0 auto;">

<!-- Hidden Action Field -->
<input type="hidden" name="action" value="register" />

<!-- Text input(First Name)-->
<div class="form-group">
  <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input name="firstName" placeholder="First Name" class="form-control"  type="text" required>
    </div>
  </div>
</div>

<!-- Text input(Last Name)--> 
<div class="form-group">
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
        <input name="lastName" placeholder="Last Name" class="form-control"  type="text" required>
    </div>
  </div>
</div>

<!-- Text input(Username)-->
<div class="form-group">
  <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input name="username" placeholder="Desired Username" class="form-control"  type="text" required>
    </div>
  </div>
</div>

<!-- Text input(Password1)--> 
<div class="form-group">
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
        <input name="password1" placeholder="Password" class="form-control"  type="password" required>
    </div>
  </div>
</div>

<!-- Text input(Password2)-->
<div class="form-group">
  <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input name="password2" placeholder="Retype Password" class="form-control"  type="password" required>
    </div>
  </div>
</div>

<!-- Text input(Email Address)--> 
<div class="form-group">
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
        <input name="emailAddress" placeholder="Email Address" class="form-control"  type="email" required>
    </div>
  </div>
</div>

<!-- Radio input(Gender) -->
<div class="form-group">
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <label class="radio-inline">
          <input type="radio" name="gender" id="genderMale" value="M"> Male
        </label>
        <label class="radio-inline">
          <input type="radio" name="gender" id="genderFemale" value="F"> Female
        </label>
    </div>
    </div>
</div>

<!-- Date input(Date Of Birth)-->
<div class="form-group">
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
        <input name="dateOfBirth" class="form-control"  type="date" required>
    </div>
  </div>
</div>

<!-- Radio input(Position)-->
<div class="form-group">
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <label class="radio-inline">
          <input type="radio" name="position" id="teacher" value="T"> Teacher
        </label>
        <label class="radio-inline">
          <input type="radio" name="position" id="student" value="S"> Student
        </label>
    </div>
    </div>
</div>

<!-- Text input(Institute)--> 
<div class="form-group">
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
        <input name="institute" placeholder="Institute" class="form-control"  type="text" required>
    </div>
  </div>
</div>

<!-- Check box(Terms & Conditions) -->
<div class="form-group">
  <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <input type="checkbox" name="T&C" class="form-control" style="margin-top: 0px; width: 18px;" required><p style="width: 250px; padding-top: 8px;"> &nbsp; <a href="T&C.php">Terms & Conditions</a></p>
    </div>
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <div class="col-md-4">
    <center>
    <button type="submit" class="btn btn-warning" > Create my MindHub account </button>
    </center>
  </div>
</div>
';

    if ( $errorMessages ) {

        echo '
<!-- Error Message --> 
<div class="form-group">
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
';

        foreach ( $errorMessages as $errorMessage ) {
            echo '      '.$errorMessage;
        }

        echo '
    </div>
  </div>
</div>';

    }

    echo '
</form>
</div>
</div>

</div>
 ';

    displayPageFooter();
}

function processForm() {
    $requiredFields = array("firstName", "lastName", "username", "password", "gender", "dateOfBirth", "emailAddress", "position");
    $missingFields = array();
    $errorMessages = array();

    $member = new Member( array(
        "firstName"=>isset( $_POST["firstName"] ) ? preg_replace( "/[^ \'\-a-zA-Z0-9]/", "", $_POST["firstName"] ) : "",
        "lastName"=>isset( $_POST["lastName"] ) ? preg_replace( "/[^ \,\-a-zA-Z0-9]/", "", $_POST["lastName"] ) : "",
        "username"=>isset( $_POST["username"] ) ? preg_replace( "/[^ \-\_a-zA-Z0-9]/", "", $_POST["username"] ) : "",
        "password"=>(isset( $_POST["password1"] ) and isset( $_POST["password2"] ) and ($_POST["password1"] == $_POST["password2"])) ? preg_replace( "/[^ \'\_a-zA-Z0-9]/", "", $_POST["password1"] ) : "",
        "gender"=>isset( $_POST["gender"] ) ? preg_replace( "/[^MF]/", "", $_POST["gender"] ) : "",
        "dateOfBirth"=>isset( $_POST["dateOfBirth"] ) ? preg_replace( "/[^ \'\_0-9]/", "", $_POST["dateOfBirth"] ) : "",
        "emailAddress"=>isset( $_POST["emailAddress"] ) ? preg_replace( "/[^ \@\.\-\_a-zA-Z0-9]/", "", $_POST["emailAddress"] ) : "",
        "position"=>isset( $_POST["position"] ) ? preg_replace( "/[^TS]/", "", $_POST["position"] ) : "",
        "institute"=>isset( $_POST["institute"] ) ? preg_replace( "/[^ \'\-a-zA-Z0-9]/", "", $_POST["institute"] ) : ""
    )	);

    foreach ( $requiredFields as $requiredField ) {
        if ( !$member->getValue($requiredField)) {
            $missingFields[] = $requiredField;
        }
    }

    if ( $missingFields ) {
        $errorMessages[] = '<p class="error">There were some missing fields in the form you submitted. Please complete the fields highlighted below and click send details to resend the form.</p>';
    }

    if ( !isset( $_POST["password1"] ) or !isset( $_POST["password2"] ) or !$_POST["password1"] or !$_POST["password2"] or ( $_POST["password1"] != $_POST["password2"] ) ) {
        $errorMessages[] = '<p class="error">Please make sure you enter your password correctly in both password fields.</p>';
    }

    if ( Member::getByUsername( $member->getValue( "username" ) ) ) {
        $errorMessages[] = '<p class="error">A member with that username already exist. Please choose another username.</p>';
    }

    if ( Member::getByEmailAddress( $member->getValue( "emailAddress" ) ) ) {
        $errorMessages[] = '<p class="error">A member with that email address already exist. Please choose another email address, or contact webmaster to retrive your password.</p>';
    }

    if ( $errorMessages ) {
        displayForm( $errorMessages, $missingFields, $member );
    }	else {
        $member->insert();
        displayThanks();
    }
}

function displayThanks() {
    echo '<center><div style="margin-top: 20px;border: 1px solid gray;border-radius: 3px;"><h4>Your account has been successfully created. Please <a href="login.php">click here</a> to login.</h4></div></center>';
}