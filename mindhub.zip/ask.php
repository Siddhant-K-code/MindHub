<?php
require_once( "common.inc.php" );
session_start();
if (!(isset($_SESSION['member']) && $_SESSION['member'] != '')) {
    header ("Location: login.php");
}

displayPageHeader('Query',true);
startWrapper();

$Queries = Query::getAllQueries();
$member = $_SESSION["member"];

echo '<div class="page-header"><h2>Questions <small>Read all the technical/non-technical questions or ask a new one.</small ></h2></div>';

if ( isset( $_POST["action"] ) and $_POST["action"] == "askQuery" ){
    processQueryForm();
} else {
    displayQueryForm(array(), array(), new Query(array()));
}

function displayQueryForm( $errorMessages, $missingFields, $member ) {

    echo '

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<h4 class="modal-title" id="myModalLabel">Incorrect Certificate Information</h4>
	  </div>
	  <div class="modal-body">';
		
		require_once("view_members.php");
		
	echo '</div>
	  <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal" onClick ="returnNames()">Done</button>
	  </div>
	</div>
  </div>
</div>

<div id="post-query">
<form class="form-horizontal" action="ask.php" method="post">

	<!-- Hidden Action Field -->
	<input type="hidden" name="action" value="askQuery" />

	<div class="form-group">
		<div class="col-sm-10">
			<input type="text" class="form-control" name="question" id="question" placeholder="question - (e.g. Technology is the only way to fix real world problems. Agree or Disagree?)" required>
		</div>
	</div>
	<div class="form-group">
		<div class="col-md-4 inputGroupContainer">
			<div class="input-group">
				<label class="radio-inline">
					<input type="radio" name="quesType" id="public" value="U"> Public
				</label>
				<label class="radio-inline">
					<input type="radio" name="quesType" id="private" value="R"> Private 
				</label>
			</div>
		</div>
	</div>
	
	<div class="form-group" name="privSec" id="privSec" hidden="True">
		<div class="col-sm-10">
			<input type="button" id="selectUsersBtn" name="selectUsersBtn" class="btn btn-default" value="Click here to select users" />
			<textarea class="form-control" name="selectedUsers" id="selectedUsers" rows="2" cols="100" readonly="readonly" value="" required>Atleast select one user from the list</textarea>
			<input type="hidden" name="selectedUsersId" id="selectedUsersId" value="" />
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-10">
			<button type="submit" class="btn btn-default">Ask the Question</button>
		</div>
	</div>
</form>
</div><br/>';


    if ( $errorMessages ) {
        foreach ($errorMessages as $errorMessage) {
            echo '      ' . $errorMessage;
        }
    }

}

function processQueryForm() {
    $requiredFields = array("question","quesType");
    $missingFields = array();
    $errorMessages = array();

    $member = $_SESSION['member'];

    $query = new Query( array(
		"quesType" => isset( $_POST["quesType"] ) ? ( $_POST["quesType"] ) : "",
        "question" => isset( $_POST["question"] ) ? ( $_POST["question"] ) : "",
        "userId" => $member->getValue("ID"),
		"selectedUsersId" => isset( $_POST["selectedUsersId"] ) ? ( $_POST["selectedUsersId"] ) : ""
    ) );

    foreach ( $requiredFields as $requiredField ) {
        if ( !$query->getValue( $requiredField ) ) {
            $missingFields[] = $requiredField;
        }
    }

    if( $missingFields ){
        $errorMessages[] = '<p class="error">Enter a topic to start a debate.</a></p>';
    } elseif ( ($queryAsked = $query->submit())<=0 ){
        $errorMessages[] = '<p class="error">The debate could not be created! Please try again or <a href="contact.php">Contact Us</a> if you are continuously facing the issue.</a></p><br>';
    }

    if ( $errorMessages ) {
        displayQueryForm( $errorMessages, $missingFields, $query );
    } else {
        echo '<div class="well well-sm">Thank you for asking a new question. <a href="answer.php?itemId='.$queryAsked.'">Click here to know more about it</a>.</div>';
    }
}

echo '<h4><span class="glyphicon glyphicon-flash"></span> Asked Questions</h4>';
echo '<div class="list-group">';

if($Queries!=null) {
    date_default_timezone_set("Asia/Kolkata");
    foreach ($Queries as $query) {
        if ( $query["quesType"] == "U" ){
			$member = Member::getMember($query["askedBy"]);
			$date = date("F jS, Y", strtotime($query["askedOn"]));
			echo '<a href="answer.php?itemId=' . $query["query_Id"] . '" class="list-group-item">' . $query["question"] . ' <small>posted on '.$date.' by '.$member->getFirstNameString().' '.$member->getLastNameString().'</small></a>';
		}
	}
}else{
    echo 'There are no Questions in the system yet. Start the activity by asking a new question.';
}
echo '</div>';

endWrapper();
displayPageFooter();

?>