<?php
require_once( "common.inc.php" );
session_start();
if (!(isset($_SESSION['member']) && $_SESSION['member'] != '')) {
    header ("Location: login.php");
}

displayPageHeader('About',true);
startWrapper();

echo '
<h1>About MindHub.</h1>
<p>Mindhub is a small startup which wants to make your as well as everyone’s work easy. Mindhub is all about you, by you, for you and with you. We are one of the most unique networks available today. With us you can share, get, learn, discuss, socialize, grow and help everyone grow.</p>
<h3>Our Policy</h3>
<p>We have an easy user policy to make everyone’s experience the best one. We have an easy layout of rules "go easy, go honest, go sure, and go respectful."</p>
<h3>Our Policy</h3>
<p>We believe in complexity which will make your life simple. We have a vision that in years you would believe so too. Making the world well versed with everything through socializing, debates and news. We just want every mouth to suggest “Go to www.mindhub.com” when you ask them about a problem.</p>
<h3>Contact Us</h3>
++919425868579
Mail:- irahul.2k@gmail.com
';

endWrapper();
displayPageFooter();

