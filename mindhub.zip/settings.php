<?php
require_once( "common.inc.php" );
require_once( "config.php" );
require_once( "Member.class.php" );
require_once( "LogEntry.class.php" );

date_default_timezone_set("Asia/Kolkata");
session_start();
if (!(isset($_SESSION['member']) && $_SESSION['member'] != '')) {
    header ("Location: login.php");
}

$member = $_SESSION["member"];

displayPageHeader('Profile',true);
startWrapper();

echo '<div class="page-header"><h2>'.$member->getFirstNameString().' '.$member->getLastNameString().'</h2></div>';

if ( isset( $_POST["action"] ) and $_POST["action"] == "Save Changes" ) {
	processForm();
} elseif ( isset( $_POST["action"] ) and $_POST["action"] == "Deactivate Account") {
	deleteMember();
} else {
	displayForm( array(), array(), $member );
}

function displayForm( $errorMessages, $missingFields, $member ) {
	echo '
	<form class="form-horizontal" action="settings.php" method="post" id="setings_form" style="margin: 0 auto;">

	<input type="hidden" name="action" value="Save Changes">
	
	Username : <input type="text" id="username" name="username" placeholder="'.$member->getUsernameString().'" required ></li>
	&nbsp; Password : <input type="password" name="password" id="password" required></li>
	<hr width=40% align=left>
	Institute : <input type="text" name="institute" id="institute" placeholder="'.$member->getInstituteString().'" required ></li>
	&nbsp; Position : <input type="text" name="position" id="position" placeholder="'.$member->getPositionString().'" required ></li>
	<br><br>
	<button type="submit" class="btn btn-warning"> Update </button>
	</form>
	';
	
    if ( $errorMessages ) {

        echo '
		<!-- Error Message --> 
		<div class="form-group">
			<div class="col-md-4 inputGroupContainer">
			<div class="input-group">
		';

        foreach ( $errorMessages as $errorMessage ) {
            echo '      '.$errorMessage;
        }

        echo '
			</div>
		  </div>
		</div>';

    }

    echo '
</form>
</div>
</div>

</div>
 ';

displayPageFooter();

}

function processForm() {
    $requiredFields = array("username", "password", "position", "institute");
    $missingFields = array();
    $errorMessages = array();
	
	$member = $_SESSION['member'];
	
    $member = new Member( array(
		"id"=>$id,
        "username"=>isset( $_POST["username"] ) ? preg_replace( "/[^ \-\_a-zA-Z0-9]/", "", $_POST["username"] ) : "",
        "password"=>isset( $_POST["password"] ) ? preg_replace( "/[^ \-\_a-zAZ0-9]/", "", $_POST["password"] ) : "",
        "position"=>isset( $_POST["position"] ) ? preg_replace( "/[^TS]/", "", $_POST["position"] ) : "",
        "institute"=>isset( $_POST["institute"] ) ? preg_replace( "/[^ \'\-a-zA-Z0-9]/", "", $_POST["institute"] ) : ""
    )	);

    foreach ( $requiredFields as $requiredField ) {
        if ( !$member->getValue($requiredField)) {
            $missingFields[] = $requiredField;
        }
    }

    if ( $missingFields ) {
        $errorMessages[] = '<p class="error">There were some missing fields in the form you submitted.</p>';
    }

 #   if ( !isset( $_POST["password1"] ) or !isset( $_POST["password2"] ) or !$_POST["password1"] or !$_POST["password2"] or ( $_POST["password1"] != $_POST["password2"] ) ) {
 #       $errorMessages[] = '<p class="error">Please make sure you enter your password correctly in both password fields.</p>';
 #   }

 #   if ( Member::getByUsername( $member->getValue( "username" ) ) ) {
 #       $errorMessages[] = '<p class="error">A member with that username already exist. Please choose another username.</p>';
 #   }

 #   if ( Member::getByEmailAddress( $member->getValue( "emailAddress" ) ) ) {
 #       $errorMessages[] = '<p class="error">A member with that email address already exist. Please choose another email address, or contact webmaster to retrive your password.</p>';
 #   }

    if ( $errorMessages ) {
        displayForm( $errorMessages, $missingFields, $member );
    }	else {
        $member->update( $member->getIdString() );
        displayThanks();
    }

}

function displayThanks() {
	header("Location: home.php");
}
?>