<?php
$start = isset( $_GET["start"] ) ? (int)$_GET["start"] : 0;
$order = isset( $_GET["order"] ) ? preg_replace( "/[^a-zA-Z]/", "", $_GET["order"] ) : "username";
list( $members, $totalRows ) = Member::getMembers( $start, PAGE_SIZE, $order );

?>	
<div class="row">
	<?php
		$rowCount = 0;
		foreach ( $members as $member ) {
			$rowCount++;
	?>
	<div class="col-md-4" style="padding:3px;">
	<div style="border:1px solid lightgray;padding:10px;">
	<input name="checkBoxes" type="checkbox" data-id="<?php echo $member->getValue("ID")?>" data-name="<?php echo $member->getValueEncoded( "firstName" ).' '.$member->getValueEncoded( "lastName" )?>"> <?php echo $member->getValueEncoded( "firstName" ).' '.$member->getValueEncoded( "lastName" ) ?></div></div>
	<?php
		}
	?>
</div>