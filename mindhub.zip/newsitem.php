<?php
require_once( "common.inc.php" );
session_start();
date_default_timezone_set("Asia/Kolkata");

if (!(isset($_SESSION['member']) && $_SESSION['member'] != '')) {
    header ("Location: login.php");
}

displayPageHeader('News',true);
startWrapper();

$newsId = $_GET['itemId'];
$newsData = News::getNewsData($newsId);
$member = Member::getMember($newsData["user_id"]);
$date = date("F jS, Y", strtotime($newsData["date_posted"]));

echo '
<a href="news.php"><button class="btn btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to News</button></a><br><br>';

echo '<h4><span class="glyphicon glyphicon-align-left"></span> '.$newsData["news_title"].'</h4>';
echo '
<p>
<strong>Source</strong> : 
<a href="'.$newsData["news_url"].'" target="_blank">'.$newsData["news_url"].'</a>
<br>
<span style="color:#bbb;font-weight:300;"><strong>'.$member->getFirstNameString().' '.$member->getLastNameString().'</strong> on '.$date.'</span>
</p>
<hr>
';
echo '
<p class="text-justify">'.$newsData["news_description"].'</p>
';

endWrapper();
displayPageFooter();
?>