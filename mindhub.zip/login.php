<?php
require_once( "common.inc.php" );
session_start();

if(isset($_SESSION['member'])){
    header("Location: home.php");
}
if ( isset( $_POST["action"] ) and $_POST["action"] == "login" ){
    processForm();
} else {
    displayForm(array(), array(), new Member(array()));
}

function displayForm( $errorMessages, $missingFields, $member ) {
    displayPageHeader( "Login", true );

    echo '<br><br>
<div class="container" background="C:\Users\Rahul\Desktop\images\1.jpg">
<h1 class="text-center" style="font-family: Righteous;color: dimgray;margin-top: 150px;">MindHub.</h1><br/>

<div class="row">
<div class="col-md-offset-4 col-md-12 col-xs-12">
<form class="form-horizontal" action="login.php" method="post" id="login_form" style="margin: 0 auto;">

<!-- Hidden Action Field -->
<input type="hidden" name="action" value="login" />

<!-- Text input-->
<div class="form-group">
  <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input name="username" placeholder="Username" class="form-control"  type="text">
    </div>
  </div>
</div>

<!-- Text input--> 
<div class="form-group">
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
        <input name="password" placeholder="Password" class="form-control"  type="password">
    </div>
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <div class="col-md-4">
    <button type="submit" class="btn btn-warning" > Login </button><span style="font-size: large;color: gray"> or </span>
    <a href="register.php" class="btn btn-info"> Create a new account </a>
  </div>
</div>
';

if ( $errorMessages ) {

echo '
<!-- Error Message --> 
<div class="form-group">
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
';

    foreach ( $errorMessages as $errorMessage ) {
        echo '      '.$errorMessage;
    }

echo '
    </div>
  </div>
</div>';

}

echo '
</form>
</div>
</div>

</div>
 ';

    displayPageFooter();
}

function processForm() {
    $requiredFields = array( "username", "password" );
    $missingFields = array();
    $errorMessages = array();

    $member = new Member( array(
        "username" => isset( $_POST["username"] ) ? preg_replace( "/[^ \-\_a-zA-Z0-9]/", "", $_POST["username"] ) : "",
        "password" => isset( $_POST["password"] ) ? preg_replace( "/[^ \-\_a-zA-Z0-9]/", "", $_POST["password"] ) : "",
    ) );

    $username = $member->getValue( "username" );
    $password = $member->getValue( "password" );

    foreach ( $requiredFields as $requiredField ) {
        if ( !$member->getValue( $requiredField ) ) {
            $missingFields[] = $requiredField;
        }
    }

    if($missingFields){
        $errorMessages[] = '<p class="error">*Enter all the necessary fields</p>';
    }	elseif (!$loggedInMember = $member->authenticate()){
        $errorMessages[] = '<p class="error">The authentication can not be made, try Again or be a <a href="register.php">New White Hat.</a></p>';
    }

    if ( $errorMessages ) {
        displayForm( $errorMessages, $missingFields, $member );
    }	else {
        $_SESSION['member'] = $loggedInMember;
        displayThanks();
    }
}

function displayThanks() {
    header("Location:home.php");
    exit();

    displayPageFooter();
}