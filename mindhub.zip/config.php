<?php
define( "DB_DSN", "mysql:host=localhost:3306;dbname=mindhub" );
define( "DB_USERNAME", "root" );
define( "DB_PASSWORD", "" );
define( "PAGE_SIZE", 15 );
define( "TBL_MEMBERS", "members" );
define( "TBL_QUERY", "ask" );
define( "TBL_PRIVATE_QUERY", "private_questions" );
define( "TBL_ANS", "ans" );
define( "TBL_ACCESS_LOG", "accessLog" );
define( "TBL_NEWS", "news" );
define( "TBL_DEBATE", "debate" );
define( "TBL_DEBATE_COMMENTS", "debate_comments" );
define( "TBL_NOTICE", "notifications" );
?>