<?php
require_once( "common.inc.php" );
session_start();
date_default_timezone_set("Asia/Kolkata");

if (!(isset($_SESSION['member']) && $_SESSION['member'] != '')) {
    header ("Location: login.php");
}

displayPageHeader('Debate',true);
startWrapper();

$debateId = $_GET['itemId'];
$debate = Debate::getDebateData($debateId);
$forTheMotionComments = DebateComments::getAllDebatesComments($debateId,'FOR');
$againstTheMotionComments = DebateComments::getAllDebatesComments($debateId,'AGAINST');
$member = Member::getMember($debate["user_id"]);
$date = date("F jS, Y", strtotime($debate["date_posted"]));

echo '
<a href="debate.php"><button class="btn btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Back to Debate List</button></a><br><br>';

echo '<h4><span class="glyphicon glyphicon-align-left"></span> '.$debate["debate_title"].'</h4>';
echo '
<p style="color: gray;font-weight: 300;"><strong>'.$member->getFirstNameString().' '.$member->getLastNameString().'</strong> on '.$date.'</p>
<hr>
';

if ( isset( $_POST["action"] ) and $_POST["action"] == "postDebateComments" ){
    processDebateCommentForm();
} else {
    displayDebateCommentForm(array(), array(), new DebateComments(array()));
}

function displayDebateCommentForm( $errorMessages, $missingFields, $member ){

echo '
<div id="post-debate">
<form class="form-horizontal" action="debateitem.php?itemId='.$_GET["itemId"].'" method="post">

  <!-- Hidden Action Field -->
  <input type="hidden" name="action" value="postDebateComments" />
  
  <div class="form-group">
    <div class="col-sm-10">
      <input type="text" class="form-control" name="debateComment" id="debateComment" placeholder="Share your thoughts on this topic" required>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-10" style="color:gray;font-weight:300!important;">
        <label class="radio-inline">
          <input type="radio" name="commentOptions" id="inlineRadio1" value="for"> For the motion
        </label>
        <label class="radio-inline">
          <input type="radio" name="commentOptions" id="inlineRadio2" value="against"> Against the motion
        </label>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-default">Comment</button>
    </div>
  </div>
</form>
</div>';


    if ( $errorMessages ) {
        foreach ($errorMessages as $errorMessage) {
            echo '      ' . $errorMessage;
        }
    }

}

function processDebateCommentForm() {

    $requiredFields = array("comment","commentType");
    $missingFields = array();
    $errorMessages = array();

    $member = $_SESSION['member'];
    $debId = $_GET["itemId"];

    $debateComments = new DebateComments( array(
        "comment" => isset( $_POST["debateComment"] ) ? ( $_POST["debateComment"] ) : "",
        "debateId" => $debId,
        "userId" => $member->getValue("ID"),
        "commentType" => isset( $_POST["commentOptions"] ) ? ( $_POST["commentOptions"] ) : ""
    ) );

    foreach ( $requiredFields as $requiredField ) {
        if ( !$debateComments->getValue( $requiredField ) ) {
            $missingFields[] = $requiredField;
        }
    }

    if( $missingFields ){
        $errorMessages[] = '<p class="error">Please select which side of the debate are you on! For the motion or against the motion.</a></p>';
    } elseif (($commentPosted = $debateComments->submit())<=0 ){
        $errorMessages[] = '<p class="error">The comment was not posted! Please try again or <a href="contact.php">Contact Us</a> if you are continuously facing the issue.</a></p><br>';
    }

    if ( $errorMessages ) {
        displayDebateCommentForm( $errorMessages, $missingFields, $debateComments );
    } else {
        echo '<div class="well well-sm">Thank you for your valuable comment. <a href="debateitem.php?itemId='.$debId.'">Refresh page to view it</a>.</div>';
    }
}

echo '<div class="row">
<div class="col-sm-6">
<h4><span class="glyphicon glyphicon-thumbs-up"></span> For The Motion</h4>';
if($forTheMotionComments!=null) {
    foreach ($forTheMotionComments as $forComment) {
        $member = Member::getMember($forComment["user_id"]);
        $date = date("F jS, Y", strtotime($forComment["date_posted"]));
        echo '<li class="list-group-item">' . $forComment["comment"] . ' <small>posted on '.$date.' by '.$member->getFirstNameString().' '.$member->getLastNameString().'</small></li>';
    }
}
echo '</div>
<div class="col-sm-6">
<h4><span class="glyphicon glyphicon-thumbs-down"></span> Against The Motion</h4>';
if($againstTheMotionComments!=null) {
    foreach ($againstTheMotionComments as $againstComment) {
        $member = Member::getMember($againstComment["user_id"]);
        $date = date("F jS, Y", strtotime($againstComment["date_posted"]));
        echo '<li class="list-group-item">' . $againstComment["comment"] . ' <small>posted on '.$date.' by '.$member->getFirstNameString().' '.$member->getLastNameString().'</small></li>';
    }
}
echo '</div>
</div>
';

endWrapper();
displayPageFooter();
?>