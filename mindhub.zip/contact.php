<?php
require_once( "common.inc.php" );
session_start();
if (!(isset($_SESSION['member']) && $_SESSION['member'] != '')) {
    header ("Location: login.php");
}

displayPageHeader('Contact',true);
startWrapper();

echo '<div class="page-header"><h2>Contact Us <small>For any feedback or issues</small ></h2></div>';
echo '
<h4>Rahul Nair</h4>
<p>Phone : +91-9425868579</p>
<p>Email : irahul.2k@gmail.com</p>
';

endWrapper();
displayPageFooter();

